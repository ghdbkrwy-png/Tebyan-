const { MODEL_TEXT, MODEL_TEXT_FALLBACK, CORS, json, callGemini, extractText, tryParseJson } = require('./_lib');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST') return json(405, { error: 'الطريقة غير مسموحة' });

  try {
    const { fileBase64, mimeType } = JSON.parse(event.body || '{}');
    if (!fileBase64) return json(400, { error: 'لم يتم إرفاق ملف.' });

    const prompt = `أنشئ دليل دراسة بالعربية من المستند المرفق. أعد النتيجة بصيغة JSON فقط بهذا الشكل بالضبط:
{
  "keyTerms": [{"term": "مصطلح", "definition": "تعريف قصير"}],
  "faq": [{"q": "سؤال شائع مرتبط بالمستند", "a": "إجابة واضحة ومختصرة"}],
  "quiz": [{"question": "سؤال اختيار من متعدد", "options": ["خيار 1", "خيار 2", "خيار 3", "خيار 4"], "answerIndex": 0}]
}
اجعل keyTerms من 5 إلى 8 عناصر، faq من 5 إلى 6 عناصر، quiz من 4 إلى 6 أسئلة. answerIndex هو رقم الخيار الصحيح ابتداءً من 0. كل الأسئلة والمصطلحات يجب أن تستند فعليًا لمحتوى المستند فقط.`;

    const payload = {
      contents: [{
        parts: [
          { inline_data: { mime_type: mimeType || 'application/pdf', data: fileBase64 } },
          { text: prompt }
        ]
      }],
      generationConfig: { responseMimeType: 'application/json' }
    };

    const data = await callGemini(MODEL_TEXT, MODEL_TEXT_FALLBACK, payload);
    const result = tryParseJson(extractText(data));
    return json(200, result);
  } catch (err) {
    return json(500, { error: err.message });
  }
};
